let artistcontainer=document.querySelectorAll(".artistcontainer")
let playbutton=document.querySelector(".playbutton")

console.log(artistcontainer)

let visible=false

